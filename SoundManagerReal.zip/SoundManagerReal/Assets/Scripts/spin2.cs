﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spin2 : MonoBehaviour {

    public float spinforce;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(Vector3.forward * spinforce * Time.deltaTime);
    }
}
