﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeDisappear : MonoBehaviour
{
    SpriteRenderer colorChanger;

    public float rateOfFade = 1;
    

    // Start is called before the first frame update
    void Start()
    {
        colorChanger = GetComponent<SpriteRenderer>();
        
    }

    // Update is called once per frame
    void Update()
    {
        Color colorFading = colorChanger.color;
        colorChanger.color = new Color(colorFading.r, colorFading.g, colorFading.b, colorFading.a - rateOfFade * Time.deltaTime);
        if (colorFading.a <= 0)
        {
            Destroy(gameObject);
        }
        if (colorFading.a >= 10)
        {
            Destroy(this);
        }
    }
}
