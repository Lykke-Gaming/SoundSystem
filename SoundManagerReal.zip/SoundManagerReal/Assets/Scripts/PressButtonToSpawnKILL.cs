﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressButtonToSpawnKILL : MonoBehaviour
{
    public bool heldButton = false;
    public KeyCode buttonToPress = KeyCode.Space;
    public GameObject objectToSpawn;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!heldButton)
        {
            if (Input.GetKeyDown(buttonToPress))
            {
                Instantiate(objectToSpawn, transform.position + new Vector3(0, 0, 0), Quaternion.identity);
                Destroy(gameObject);
            }
        }
        else
        {
            if (Input.GetKey(buttonToPress))
            {
                Instantiate(objectToSpawn, transform.position + new Vector3(0, 0, 0), Quaternion.identity);
                Destroy(gameObject);
            }
        }
        
    }
}
