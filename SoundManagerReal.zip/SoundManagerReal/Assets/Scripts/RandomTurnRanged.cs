﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomTurnRanged : MonoBehaviour
{
	public float noscope;
	public float min = 0;
	public float max = 360;

	// Use this for initialization
	void Start()
	{
		noscope = Random.Range(min, max);
		transform.Rotate(Vector3.forward * noscope);
	}

	// Update is called once per frame
	void Update()
	{

	}
}
