﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShrinkIntoNothing : MonoBehaviour
{
    public float shrinkingAmount;
    Transform thisObject;

    // Start is called before the first frame update
    void Start()
    {
        thisObject = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.localScale.x  >= 0)
        {
            thisObject.localScale = new Vector3(transform.localScale.x - shrinkingAmount * Time.deltaTime, transform.localScale.y - shrinkingAmount * Time.deltaTime, transform.localScale.z);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
